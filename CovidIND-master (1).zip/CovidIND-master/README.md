# Covid-19 India Model
This model will predict the number of daily cases in future . This is based on Multivariate Linear Regression
